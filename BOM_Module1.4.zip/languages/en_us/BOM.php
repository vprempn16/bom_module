<?php 
$languageStrings = array(
 'LBL_EXPORT_TO_PDF' => 'Export to PDF',
    'LBL_SEND_MAIL_PDF' => 'Send Email with PDF',
);
$jsLanguageStrings = array(
);



?>
