<?php 
class BOMCustom{ 
	public function postEnable(){
		$this->addHeaderJs();
		$this->eventhandler();
		$this->relatedField();
	}
	public function postInstall(){
		global $adb;
		$this->addHeaderJs();
		$this->eventhandler();
		$modules = ["Invoice","SalesOrder","Quotes","PurchaseOrder","BOM","ITS4YouIssuecards","ITS4YouReceiptcards","ITS4YouWarehouseTransfers","ITS4YouWHDeliveryNotes","ITS4YouPreInvoice","CreditNotes4You"];
		foreach($modules as $module ){
			$this->relateModule($module , "Products" , "Products","get_related_list");
			$this->relateModule($module , "Services" , "Services","get_related_list");
		}
		$this->relatedField();
		$modules = array("PurchaseOrder" => array( 'fieldname' => 'bom' , 'module_label' => 'Purchase Orders' ) , "SalesOrder" => array( 'fieldname' => 'bom' , 'module_label' => 'Sales Orders' ) );
		foreach($modules as $module => $moduledetails){
			$tabid = getTabId( $module );
			$fieldid_res = $adb->pquery( "SELECT fieldid FROM vtiger_field WHERE fieldname = ? AND tabid = ?" , ARRAY( $moduledetails['fieldname'] , $tabid  ) );
			if( $adb->num_rows( $fieldid_res ) > 0 ) {
				$fieldid = $adb->query_result( $fieldid_res , 0 , 'fieldid' );
				$result = $this->relateModule( 'BOM' , $module , $moduledetails['module_label'], "get_dependents_list" , array( "ADD" ) , $fieldid );
			}

		}
	}
	public function postDisable(){
		global $adb;
		$this->removeHeaderJs();
		$this->unregisterEventHandler();
		$this->rmvField();
	}
	public function postUpdate(){
		global $adb;
		$this->addHeaderJs();      
		$this->eventhandler();
		$modules = ["Invoice","SalesOrder","Quotes","PurchaseOrder","BOM","ITS4YouIssuecards","ITS4YouReceiptcards","ITS4YouWarehouseTransfers","ITS4YouWHDeliveryNotes","ITS4YouPreInvoice","CreditNotes4You"];
		foreach($modules as $module ){
			$this->relateModule($module , "Products" , "Products","get_related_list");
			$this->relateModule($module , "Services" , "Services","get_related_list");
		}
		$this->relatedField();
		$modules = array("PurchaseOrder" => array( 'fieldname' => 'bom' , 'module_label' => 'Purchase Orders' ) , "SalesOrder" => array( 'fieldname' => 'bom' , 'module_label' => 'Sales Orders' ) );
		foreach($modules as $module => $moduledetails){
			$tabid = getTabId( $module );
			$fieldid_res = $adb->pquery( "SELECT fieldid FROM vtiger_field WHERE fieldname = ? AND tabid = ?" , ARRAY( $moduledetails['fieldname'] , $tabid  ) );
			if( $adb->num_rows( $fieldid_res ) > 0 ) {
				$fieldid = $adb->query_result( $fieldid_res , 0 , 'fieldid' );
				$result = $this->relateModule( 'BOM' , $module , $moduledetails['module_label'], "get_dependents_list" , array( "ADD" ) , $fieldid );
			}

		}
	}

	public function addHeaderJs(){
		global $adb;
		$linklabel = "BOMHeader";
		$linkurl = "layouts/v7/modules/BOM/resources/BOMHeader.js";
		$result = $adb->pquery("SELECT * FROM vtiger_links WHERE linklabel = ? AND linkurl = ? ",array($linklabel,$linkurl));
		$num_rows = $adb->num_rows($result);
		if($num_rows == 0){
			$moduleName='Home';
			$moduleInstance = Vtiger_Module::getInstance($moduleName);
			$moduleInstance->addLink('HEADERSCRIPT', $linklabel,$linkurl);
		}
	}
	public function removeHeaderJs(){
		$linklabel = "BOMHeader";
		$linkurl = "layouts/v7/modules/BOM/resources/BOMHeader.js";
		Vtiger_Link::deleteLink( 3 , 'HEADERSCRIPT' , $linklabel , $linkurl );
	}
	public function eventhandler(){
		$Vtiger_Utils_Log = true;
		include_once('vtlib/Vtiger/Event.php');
		Vtiger_Event::register('BOM', 'vtiger.entity.aftersave', 'BOMHandler', 'modules/BOM/BOMHandler.php');
	}
	public function unregisterEventHandler(){
		global $adb;
		$Vtiger_Utils_Log = true;
		include_once('include/events/VTEventsManager.inc');
		$class = 'BOMHandler';
		$result  = $adb->pquery('SELECT * FROM vtiger_eventhandlers WHERE handler_class =?',array($class));
		if($adb->num_rows($result) > 0){
			$eventsManager = new VTEventsManager($adb);
			$result = $eventsManager->unregisterHandler($class);
			return "success";
		}else{
			return "handler not found";
		}
	}
	public function addInitWebservice($moduleName){
		global $adb;
		$filePath = 'include/Webservices/VtigerModuleOperation.php';
		$className = 'VtigerModuleOperation';
		$checkres = $adb->pquery('SELECT id FROM vtiger_ws_entity WHERE name=? AND handler_path=? AND handler_class=?',
			array($moduleName, $filePath, $className));
		if($checkres && $adb->num_rows($checkres) == 0) {
			$isModule=1;
			$entityId = $adb->getUniqueID("vtiger_ws_entity");
			$adb->pquery('insert into vtiger_ws_entity(id,name,handler_path,handler_class,ismodule) values (?,?,?,?,?)',
				array($entityId,$moduleName,$filePath,$className,$isModule));
		}
	}
	public function relateModule( $SourceModuleName , $RelatedModuleName , $relatedmodulelabel , $relation_function = "get_related_list" , $relation_actions = array( ) , $fieldid = '' )
	{
		global $adb;
		$SourceModuleObj = Vtiger_Module::getInstance( $SourceModuleName );
		$RelatedModuleObj = Vtiger_Module::getInstance( $RelatedModuleName );
		$SourceModuleTabId = getTabId( $SourceModuleName );
		$RelatedModuleTabId = getTabId( $RelatedModuleName );
		$vtiger_relatedlists_result = $adb->pquery( "select relation_id from vtiger_relatedlists where tabid = ? and related_tabid = ? and name = ? and label = ?"  , array( $SourceModuleTabId , $RelatedModuleTabId , $relation_function , $relatedmodulelabel ) );
		if( $adb->num_rows( $vtiger_relatedlists_result ) == 0 ) {
			$SourceModuleObj->setRelatedList( $RelatedModuleObj , $relatedmodulelabel , $relation_actions , $relation_function , $fieldid );
			$result = array( 'result' => 'success' , 'messagetype' => 'success' , 'messagetitle' => 'Success' , 'action' => $relation_actions , 'message' => 'Relation Created' );
		}
		else {
			$result = array( 'result' => 'failed' , 'messagetype' => 'failed' , 'messagetitle' => 'Failed to create Relation' , 'action' => $relation_actions , 'message' => "Relation with label {$relatedmodulelabel} between the modules {$SourceModuleName} and {$RelatedModuleName} with the relation type {$relation_function} already exist" );
		}
		return $result;
	}
	public function relatedField(){
		$modules = array("PurchaseOrder","SalesOrder");
		foreach($modules as $module){
			$moduleInstance = Vtiger_Module::getInstance($module);
			if($module == 'PurchaseOrder'){
				$blocklabel = 'LBL_PO_INFORMATION';
			}else{
				$blocklabel = 'LBL_SO_INFORMATION';
			}
			$blocklineitem = Vtiger_Block::getInstance( $blocklabel, $moduleInstance );
			$field1 = Vtiger_Field::getInstance("bom",$moduleInstance);
			if(!$field1){
				$field1 = new Vtiger_Field();
				$field1->name = "bom";
				$field1->label = "Bill Of Matrial";
				$field1->column = "bom";
				$field1->columntype = 'VARCHAR(250)';
				$field1->uitype = 10;
				$field1->presence = 2;
				$blocklineitem->addField($field1);
				$field1->setRelatedModules( array( "BOM" ) );
			}
		}
	}
	public function rmvField(){
		$modules = array("PurchaseOrder","SalesOrder");
		foreach($modules as $module){
			$moduleInstance = Vtiger_Module::getInstance ($module );
			$field = 'bom';
			$fieldInstance = Vtiger_Field::getInstance ( $field, $moduleInstance );
			if ($fieldInstance) {
				$fieldInstance->delete();
			}
		}
	}
} 


