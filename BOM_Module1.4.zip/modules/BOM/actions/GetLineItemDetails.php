<?php          
class BOM_GetLineItemDetails_Action extends Vtiger_Action_Controller {      
	public function process(Vtiger_Request $request) {     
		global $adb;  
		$moduleName = $request->get('module');
		$recordId = $request->get('record');   
		$currentModel = Vtiger_Record_Model::getInstanceById($recordId);
		if (!$recordId) {
			$response = new Vtiger_Response();
			$response->setResult(['success' => false, 'message' => 'No record ID found']);
			$response->emit();
			return;
		}	
		$query = "SELECT lineitem_id,listprice,productid,sequence_no ,baseqty FROM vtiger_inventoryproductrel  INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = vtiger_inventoryproductrel.productid WHERE id = ? AND deleted=0";
		$result = $adb->pquery($query, [$recordId]);
		$qty_multiple = $currentModel->get('qty_multiple');
		$itemDetails = [];
		$listPriceValuesList = $listPricesList = array();
		while ($row = $adb->fetch_array($result)) {
			$id = $row['lineitem_id'];
			$sequence_no = $row['sequence_no'];
			$productid = $row['productid'];
			$relmodule = getSalesEntityType($productid);
			$itemDetails[$sequence_no] = [
				'productid' => $row['productid'],
				'lineItemId' => $row['lineitem_id'],
				'module' => $relmodule,
				'baseqty' => $row['baseqty'],
				'listprice' => $row['listprice'],
			];
		}
		$qty_multiple = $currentModel->get('qty_multiple');
		$itemDetails['qty_multiple'] = $qty_multiple;
		$response = new Vtiger_Response();
		$response->setResult([
			'success' => true,
			'itemDetails' => json_encode($itemDetails),
		]);
		$response->emit();
	
	}

}
