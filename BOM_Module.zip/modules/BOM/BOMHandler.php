<?php 
class BOMHandler{
	function handleEvent($eventName, $entityData) {
		global $adb;
		$recordid = $entityData->getId();
		if ($eventName == 'vtiger.entity.aftersave') {
			$moduleName = $entityData->getModuleName();
			if (in_array($moduleName, ['Invoice', 'SalesOrder', 'Quotes','PurchaseOrder','BOM'])) {
				$requestData = $_REQUEST;
				$adb->pquery(
					"DELETE FROM vtiger_crmentityrel WHERE crmid = ? AND module = ? AND relmodule = ?",
					[$recordid, $moduleName, 'Products']
				);
				$query = "SELECT lineitem_id, productid, sequence_no FROM vtiger_inventoryproductrel WHERE id = ? ORDER BY sequence_no";
				$result = $adb->pquery($query, [$recordid]);
				while ($row = $adb->fetch_array($result)) {
					$lineItemId = $row['lineitem_id'];
					$productId = $row['productid'];
					$sequenceNo = $row['sequence_no'];
					if (!empty($productId)) {
						$checkRes = $adb->pquery(
							"SELECT 1 FROM vtiger_crmentityrel WHERE crmid = ? AND module = ? AND relcrmid = ? AND relmodule = ?", [$recordid, $moduleName, $productId, 'Products'] );
						if ($adb->num_rows($checkRes) == 0) {
							$adb->pquery(
								"INSERT INTO vtiger_crmentityrel (crmid, module, relcrmid, relmodule) VALUES (?, ?, ?, ?)",
								[$recordid, $moduleName, $productId, 'Products']
							);
						}
					}
				}
				if (in_array($moduleName, ['BOM'])) {
					$qty_multiple = $requestData['qty_multiple'];
					if($qty_multiple !== '' && $moduleName == 'BOM'){
						$query = "UPDATE vtiger_bom SET qty_multiple = ? WHERE bomid = ?";
						$params = [$qty_multiple, $recordid];
						$adb->pquery($query, $params);
					}
				}
			}
		}
	}
} 




?>
